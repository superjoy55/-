package jp.co.bbreak.sokusen._5._1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 스레드풀 샘플 
 */
public class ThreadPoolSample implements Runnable {

	/** 출력 메시지 템플릿 */
	private static final String MSG_TEMPLATE = "출력중입니다. [%s][%d회째]";

	/** 스레드 이름 */
	private final String threadName;
	
	public ThreadPoolSample(String threadName) {
		this.threadName = threadName;
	}
	
	public void run() {
		for (int i = 1; i < 100; i++) {
			System.out.println(String.format(MSG_TEMPLATE, threadName, i));
		}
	}
	
	public static void main(String[] args) {
		ThreadPoolSample runnable1 = new ThreadPoolSample("thread1");
		ThreadPoolSample runnable2 = new ThreadPoolSample("thread2");
		ThreadPoolSample runnable3 = new ThreadPoolSample("thread3");
		
		// 스레드 동시 실행 수는 3스레드
		ExecutorService executorService = Executors.newFixedThreadPool(3);
		executorService.execute(runnable1);
		executorService.execute(runnable2);
		executorService.execute(runnable3);
		
		executorService.shutdown();
		try {
			if (!executorService.awaitTermination(5, TimeUnit.MINUTES)) {
				// 타임아웃 후에도 아직 실행이 끝나지 않았다
				executorService.shutdownNow();
			}
		} catch (InterruptedException e) {
			// 종료 대기 시에 뭔가 오류가 발생했다
			e.printStackTrace();
			executorService.shutdownNow();
		}
	}

}
