package jp.co.bbreak.sokusen._3._5;

import java.sql.*;

public class UpdateSample2 {
	public static void main(String args[]) {
		// JDBC 드라이버 로딩 
		try {
			// postgreSQL의 JDBC 드라이버 로딩
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// JDBC 드라이버가 없는 경우
			e.printStackTrace();
		}

		// 1.데이터베이스 접속 
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql:javasample", "postgres", "password");) {
			// 2.커밋모드 변경
			conn.setAutoCommit(false);
			
			// 3.UPDATE문의 발행과 결과 획득
			// Statement 오브젝트 생성
			Statement stmt = conn.createStatement();
			// UPDATE문 발행과 결과 획득
			int result = stmt.executeUpdate("UPDATE book SET price=600 WHERE name = 'ビジネス書'");
			// 갱신된 라인 수 표시 
			System.out.println(result);
			
			// 4.변경 반영(커밋)
			conn.commit();

		} catch (SQLException e) {
			// 롤백처리 생략
			
			// 접속 UPDATE문 발행에서 오류가 발생한 경우 
			e.printStackTrace();
		}
	}
}