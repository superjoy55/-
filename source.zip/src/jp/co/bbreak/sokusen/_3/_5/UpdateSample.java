package jp.co.bbreak.sokusen._3._5;

import java.sql.*;

public class UpdateSample {
	public static void main(String args[]) {
		// 데이터베이스 접속정보를 저장할 변수 
		Connection conn = null;

		// JDBC 드라이버 로딩 
		try {
			// postgreSQL의 JDBC 드라이버 로딩
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// JDBC 드라이버가 없을 경우 
			e.printStackTrace();
		}

		try {
			// 1.데이터베이스 접속
			conn = DriverManager.getConnection("jdbc:postgresql:javasample", "postgres", "password");

			// 2.커밋 모드 변경
			conn.setAutoCommit(false);
			
			// 3.UPDATE문 발행과 결과 획득
			// Statement 오브젝트 생성
			Statement stmt = conn.createStatement();
			// UPDATE문 발행과 결과 획득
			int result = stmt.executeUpdate("UPDATE book SET price=600 WHERE name = '비즈니스서적'");
			// 갱신한 줄의 숫자 표시
			System.out.println(result);
			
			// 4.변경 반영(커밋)
			conn.commit();

		} catch (SQLException e) {
			try {
				// 롤백 
				conn.rollback();
			} catch(SQLException ex) {
				// 롤백으로 오류가 발생한 경우
				ex.printStackTrace();
			}
			
			// 접속, UPDATE문 발행에서 오류가 발생한 경우
			e.printStackTrace();
		} finally {
			// 4.데이터베이스 접속 해제 
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					// 데이터베이스 접속 해제에서 오류가 발생한 경우
					e.printStackTrace();
				}
			}
		}
	}
}