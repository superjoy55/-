package jp.co.bbreak.sokusen._3._4;

import java.sql.*;

public class SelectSample2 {
	public static void main(String args[]) {
		// JDBC 드라이버 로딩
		try {
			// postgreSQL의 JDBC 드라이버 로딩
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// JDBC 드라이버를 찾지 못한 경우 
			e.printStackTrace();
		}

		// 1.데이터베이스 접속
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql:javasample", "postgres", "password");) {
			// 2.SELECT문 발행과 결과 획득
			// Statement 오브젝트 생성
			Statement stmt = conn.createStatement();
			// SELECT문을 발행하고 검색 결과를 저장한다 
			ResultSet rset = stmt.executeQuery("SELECT * FROM book");

			// 3.결과 표시 
			while (rset.next()) {
				System.out.println(rset.getString("name"));
			}
		} catch (SQLException e) {
			// 접속, SELECT문 발행에서 오류가 발생한 경우
			e.printStackTrace();
		}
	}
}