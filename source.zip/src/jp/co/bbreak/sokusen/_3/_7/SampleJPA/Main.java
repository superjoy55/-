import javax.persistence.*;

public class Main {

	public static void main(String[] args) {
		// EntityManager 생성
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("SampleJPA");
		EntityManager em = emf.createEntityManager();

		// 트랜잭션 시작 
		EntityTransaction et = em.getTransaction();
		et.begin();

		// 엔티티 생성
		Weather weather = new Weather();
		weather.setDate("2016-02-10");
		weather.setWeather("맑음");

		// 테이블에 저장 
		em.persist(weather);

		// 트랜잭션 종료(커밋)
		et.commit();

		// 테이블에서 데이터를 추출
		Weather result = em.find(Weather.class, "2016-02-10");
		System.out.println(result.getWeather());

		// EntityManager 닫기 
		em.close();
		emf.close();
	}
}
