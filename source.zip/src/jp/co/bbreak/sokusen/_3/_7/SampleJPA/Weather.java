import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Weather
 *
 */
@Entity

public class Weather implements Serializable {

	   
	@Id
	private String date;
	private String weather;
	private static final long serialVersionUID = 1L;

	public Weather() {
		super();
	}   
	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}   
	public String getWeather() {
		return this.weather;
	}

	public void setWeather(String weather) {
		this.weather = weather;
	}
   
}
