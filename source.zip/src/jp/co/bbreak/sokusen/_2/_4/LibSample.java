package jp.co.bbreak.sokusen._2._4;

import org.apache.commons.lang.StringUtils;

public class LibSample {
	public static void main(String[] args) {
		String targetStr = "체크대상문자";
		
		if (StringUtils.isEmpty(targetStr)) {
			System.out.println("비었습니다.");
		} else {
			System.out.println("비어있지 않습니다.");
		}
	}
}
