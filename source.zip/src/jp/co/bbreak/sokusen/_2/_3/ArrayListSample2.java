package jp.co.bbreak.sokusen._2._3;

import java.util.*;

public class ArrayListSample2 {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		
		// 맨끝에 요소를 추가
		list.add("철수");
		list.add("영희");
		list.add("길동");
		
		// 모든 요소를 표시 
		for(int i = 0; i < list.size(); i++) {
			System.out.println(i + "번:" + list.get(i));
		}
	}
}