package jp.co.bbreak.sokusen._2._3;

import java.util.*;

public class ArrayListSample1 {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		
		// 맨긑에 요소를 추가
		list.add(17);
		list.add(51);
		list.add(39);
		
		// 요소 표시
		System.out.println("***1번째 표시***");
		System.out.println("0번 요소:" + list.get(0));
		System.out.println("1번 요소:" + list.get(1));
		System.out.println("2번 요소:" + list.get(2));
		
		// 요소 삭제
		list.remove(1);
		
		// 요소 표시
		System.out.println("***2번째 표시***");
		System.out.println("0번 요소:" + list.get(0));
		System.out.println("1번 요소:" + list.get(1));		
	}
}