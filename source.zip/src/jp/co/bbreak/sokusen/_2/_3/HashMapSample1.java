package jp.co.bbreak.sokusen._2._3;

import java.util.*;

public class HashMapSample1 {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();

		// 키와 값을 쌍으로 저장
		map.put("빨강", "사과");
		map.put("보라", "포도");
		map.put("노랑", "귤");
		
		// 요소 삭제 
		map.remove("빨강");
		
		// 값을 표시 
		for(String key : map.keySet()) {
			String value = key;
			System.out.println(value);
		}
	}
}