package jp.co.bbreak.sokusen._2._3;

import java.util.*;

public class ArrayListSample3 {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
	
		// 맨끝에 효소를 추가
		list.add("철수");
		list.add("영희");
		list.add("길동");
		
		// 이터레이터 취득 
		Iterator<String> it = list.iterator();
		
		// 모든 요소 표시
		while(it.hasNext()) {
			// 요소 추출 
			String name = it.next();
			System.out.println(name);
		}
	}
}