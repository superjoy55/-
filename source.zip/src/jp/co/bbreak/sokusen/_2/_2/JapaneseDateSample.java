package jp.co.bbreak.sokusen._2._2;

import java.time.Month;
import java.time.chrono.JapaneseDate;

public class JapaneseDateSample {
	public static void main(String[] args) {
		JapaneseDate japaneseDate = JapaneseDate.of(2016, Month.FEBRUARY.getValue(), 29);
		System.out.println(japaneseDate);
	}
}
