package jp.co.bbreak.sokusen._1._7;

/**
 * for문 예제를 실행하고 내용을 확인하는 클래스.
 */
public class ForStatement {

    /**
     * for문을 실행하고 내용을 확인합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        // [1] for문
        System.out.println("------- 카운터를 이용한 예제 -------");
        String stringValue = "가나다라마";
        for (int i = 0; i < stringValue.length(); i++) {
            System.out.println("[1] " + stringValue.charAt(i));
        }

        System.out.println("------- 배열을 이용한 예제 -------");
        char[] chars = stringValue.toCharArray();
        for (char charValue : chars) {
            System.out.println("[2] " + charValue);
        }
    }
}