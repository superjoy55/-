package jp.co.bbreak.sokusen._1._7;

/**
 * break문 및 continue문 예제를 실행하고 내용을 확인하는 클래스
 */
public class BreakAndContinueSample1 {

    /**
     * break문 및 continue문을 실행하고 내용을 확인합니다. 
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {

        System.out.println("------- [1] break -------");
        for (int i = 0; i < 3; i++) {
            if (i == 1) {
                break;
            }
            System.out.println("i=" + i);
        }

        System.out.println("------- [2] continue -------");
        for (int i = 0; i < 3; i++) {
            if (i == 1) {
                continue;
            }
            System.out.println("i=" + i);
        }
    }
}