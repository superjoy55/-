package jp.co.bbreak.sokusen._1._8._6;

public class Main {
	public static void main(String[] args) {
		Employee employee1;
		Employee employee2;
		
		// 찻 번째는 관리직
		employee1 = new Manager();
		// 두 번째는 아르바이트
		employee2 = new PartTime();

		// 응답 메서드 실행 
		employee1.echo();
		employee2.echo();
	}
}