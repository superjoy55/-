package jp.co.bbreak.sokusen._1._8._7;

public class Employee {
	// 응답 메서드
	public void echo() {
		System.out.println("사원입니다.");
	}
}