package jp.co.bbreak.sokusen._1._8._4;

public class Parent {
	Parent() {
		System.out.println("부모 클래스의 생성자입니다.");
	}
}