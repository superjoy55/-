package jp.co.bbreak.sokusen._1._8._6;

public class ImplementsSample implements InterfaceSample {
	public String sampleMethod1() {
		return "샘플1";
	}

	public String sampleMethod2(int num) {
		return "샘플2";
	}
}