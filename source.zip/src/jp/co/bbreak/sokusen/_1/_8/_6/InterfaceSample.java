package jp.co.bbreak.sokusen._1._8._6;

public interface InterfaceSample {
	abstract String sampleMethod1();
	abstract String sampleMethod2(int num);
}