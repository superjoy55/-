package jp.co.bbreak.sokusen._1._8._6;

public interface Employee {
	// 응답 메서드
	public abstract void echo();
}