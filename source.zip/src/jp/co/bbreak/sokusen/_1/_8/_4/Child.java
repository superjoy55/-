package jp.co.bbreak.sokusen._1._8._4;

public class Child extends Parent{
	Child() {
		System.out.println("자식 클래스의 생성자입니다.");
	}
}