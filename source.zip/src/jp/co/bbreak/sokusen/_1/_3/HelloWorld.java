package jp.co.bbreak.sokusen._1._3;

/**
 * 「HelloWorld!!」라고 표준출력하는 클래스입니다.
 */
public class HelloWorld {

    /**
     * HelloWorld클래스를 java명령으로 호출했을 때 실행될 처리입니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용되지 않습니다.
     */
    public static void main(String[] args) {
        System.out.println("Hello World!!");
    }
}