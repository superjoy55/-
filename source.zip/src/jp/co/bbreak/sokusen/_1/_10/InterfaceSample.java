package jp.co.bbreak.sokusen._1._10;

public interface InterfaceSample {
	abstract void sampleMethod(String name);
}