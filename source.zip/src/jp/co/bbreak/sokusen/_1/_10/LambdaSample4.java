package jp.co.bbreak.sokusen._1._10;

public class LambdaSample4 {
	public static void main(String[] args) {
		// 람다식으로 처리를 구현한다(return과 괄호를 생략한다)
		InterfaceSample1 lambda = name -> name + "입니다.";
		
		// 구현한 처리를 실행
		System.out.println(lambda.sampleMethod("길동"));
	}
}