package jp.co.bbreak.sokusen._1._10;

public class LambdaSample {
	public static void main(String[] args) {
		// 람다식으로 처리를 구현한다
		InterfaceSample lambda = (String name) -> {
			System.out.println(name + "입니다. ");
		};
		
		// 구현한 처리를 사용한다
		lambda.sampleMethod("길동");
	}
}