package jp.co.bbreak.sokusen._1._10;

public interface InterfaceSample1 {
	abstract String sampleMethod(String name);
}