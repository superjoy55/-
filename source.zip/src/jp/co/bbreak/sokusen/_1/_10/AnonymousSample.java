package jp.co.bbreak.sokusen._1._10;

public class AnonymousSample {
	public static void main(String[] args) {
		// 익명  클래스로 처리를 구현한다
		InterfaceSample anonymous = new InterfaceSample() {
			public void sampleMethod(String name) {
				System.out.println(name + "입니다. ");
			}
		};
		
		// 구현한 메서드 사용
		anonymous.sampleMethod("길동");
	}
}