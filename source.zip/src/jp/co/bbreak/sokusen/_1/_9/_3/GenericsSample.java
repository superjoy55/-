package jp.co.bbreak.sokusen._1._9._3;

public class GenericsSample<E> {
	private E object;
	
	// 게터
	public E getObject() {
		return this.object;
	}
	
	// 세터
	public void setObject(E object) {
		this.object = object;
	}
}