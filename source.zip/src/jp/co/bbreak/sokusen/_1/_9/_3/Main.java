package jp.co.bbreak.sokusen._1._9._3;

public class Main {
	public static void main(String[] args) {
		// 제네릭을 사용한 크래스의 인스턴스 생성
		GenericsSample<String> generic = new GenericsSample<String>();

		// 세터 실행 
		generic.setObject("안녕하세요.");
		
		// 게터 실행 
		System.out.println(generic.getObject());
	}
}