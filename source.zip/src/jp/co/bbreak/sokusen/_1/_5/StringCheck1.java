package jp.co.bbreak.sokusen._1._5;

/**
 * 문자열 데이터의 참조를 체크한다
 */
public class StringCheck1 {

    /**
     * 2개의 String 변수에 같은 큰따옴표로 에워싼 문자열을 참조하게 한 경우, 같은 것을 가리키는지 표준출력합니다.
     * 
     * @param args
     *            커맨드라인 인수. 이번에는 사용하지 않습니다.
     */
    public static void main(String[] args) {
        String a = "가나다라마";
        String b = "가나다라마";

        // a 와 b가 같은 참조처를 가리키고 있는지 비교해, 같을 때는 true가 됩니다.
        boolean result = (a == b);
        System.out.println("a == b: " + result);
    }
}