package jp.co.bbreak.sokusen._4._1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadText3 {

	public static void main(String[] args) {
		try {

			// 파일 오브젝트 생성
			File file = new File("c:\\sokusen\\Sample.txt");

			// Scanner 오브젝트 생성 
			Scanner scan = new Scanner(file);

			// while문으로 파일을 읽어 들인다
			System.out.println(scan.useDelimiter("\\z").next());

			// 입력 스트림을 닫는다
			scan.close();

		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
	}
}
