package jp.co.bbreak.sokusen._4._1;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ReadText4 {

	public static void main(String[] args) {

		// 파일 오브젝트 생성 
		Path path = Paths.get("c:\\sokusen\\Sample.txt");

		// 문자 세트를 지정한다
		Charset cs = StandardCharsets.UTF_8;
		List<String> list = new ArrayList<String>();

		try {

			list = Files.readAllLines(path, cs);

		} catch (IOException e) {
			e.printStackTrace();
		}

		// 가져온 텍스트 내용을 출력 
		for (String readLine : list) {
			System.out.println(readLine);
		}
	}
}