package jp.co.bbreak.sokusen._4._1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadText2 {

	public static void main(String[] args) {
		try {

			// 파일 오브젝트 생성 
			File file = new File("c:\\sokusen\\Sample.txt");
			FileReader fRd = new FileReader(file);
			BufferedReader bufRd = new BufferedReader(fRd);

			String line = "";

			// while문을 이용해 파일을 읽어 들인다
			while ((line = bufRd.readLine()) != null) {
				System.out.println(line);
			}

			// 입력 스트림을 닫는다
			bufRd.close();

		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
	}
}
