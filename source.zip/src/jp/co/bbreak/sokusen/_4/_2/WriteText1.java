package jp.co.bbreak.sokusen._4._2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteText1 {

	public static void main(String[] args) {

		try {
			// 출력할 파일 File 오브젝트 생성 
			File file = new File("c:\\sokusen\\sampleWrite1.txt");

			// FileWriter 오브젝트를 생성（추가기록 모드）
			FileWriter fw = new FileWriter(file, true);

			// 문자열 출력
			fw.write("출력문자열１\r\n");
			fw.write("출력문자열２\r\n");

			// FileWriter 오브젝트 닫기
			fw.close();

		} catch (IOException e) {
			System.out.println(e);
		}
	}
}
