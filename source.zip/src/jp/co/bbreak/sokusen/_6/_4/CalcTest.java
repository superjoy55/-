package jp.co.bbreak.sokusen._6._4;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.Test;

public class CalcTest {

	@Test
	public void add메서드테스트() {
		Calc calc = new Calc();
		int result = calc.add(1, 2);
		
		// 계산결과 비교
		assertThat(result, is(3));
	}
}