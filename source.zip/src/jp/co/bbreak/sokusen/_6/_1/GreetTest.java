//package jp.co.bbreak.sokusen._6._1;
public class GreetTest {

	public static void main(String[] args) {
		// Greet 클래스를 테스트 실행한다 
		Greeting2 g = new Greeting2();
		g.greet();
	}
}