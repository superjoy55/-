package jp.co.bbreak.sokusen._6._3.JUnitTest;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;

import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.junit.*;
import junit.framework.TestCase;

public class UserDAOTest extends TestCase {
	@Before
	public void setUp() throws Exception {
		// DbUnit용 데이터베이스 접속 
		IDatabaseConnection dbConnection = null;
		Class.forName("org.h2.Driver");

		// test 데이터베이스에 sa 유저（암호없음）로 H2DB에 접속
		try(Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");) {
			dbConnection = new DatabaseConnection(con);

			// 테스트용 데이터를 읽어 들인다
			IDataSet dataSet = new FlatXmlDataSet(
					new FileInputStream("src/test/resources/user_data.xml"));
			// 테스트용 데이터를 테이블에 삽입한다
			DatabaseOperation.CLEAN_INSERT.execute(dbConnection, dataSet);

		}
	}

	@Test
	public void testFindByUserid() {
		UserDAO userDao = new UserDAO();
		User user = userDao.findByUserid("0001");
		
		// 테스트 결과를 검증한다
		assertThat(user.getName(), is("테스트일남"));
	}
}